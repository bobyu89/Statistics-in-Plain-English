# t 分布

- English:t distribution
- 出處:[[CH06 標準誤]]、[[CH09 t 檢定]]

形狀隨自由度改變的分布族;母體標準差未知或樣本小時使用。
